﻿Public Class FormBaseEnum

    Public Enum FormMode
        ADD
        EDIT
        VIEW
        DELETE
    End Enum

End Class
