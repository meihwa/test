﻿Namespace $safeprojectname$

    Public Class StatusDescription
        Public Function StatusDescription(ByVal StatusCode As String) As String
            Select Case StatusCode
                Case "-"
                    StatusDescription = "-"
                Case "N"
                    StatusDescription = "New"
                Case "S"
                    StatusDescription = "Submit"
                Case "P"
                    StatusDescription = "Process"
                Case "A"
                    StatusDescription = "Approved"
                Case "R"
                    StatusDescription = "Reject"
                Case "V"
                    StatusDescription = "Revise"
                Case "H"
                    StatusDescription = "History"
                Case Else
                    StatusDescription = ""
            End Select

            Return StatusDescription
        End Function

        Public Function StatusCode(ByVal StatusDescription As String) As String
            Select Case Trim(StatusDescription)
                Case "-"
                    StatusCode = "-"
                Case "New"
                    StatusCode = "N"
                Case "Submit"
                    StatusCode = "S"
                Case "Process"
                    StatusCode = "P"
                Case "Approved"
                    StatusCode = "A"
                Case "Reject"
                    StatusCode = "R"
                Case "Revise"
                    StatusCode = "V"
                Case "History"
                    StatusCode = "H"
                Case Else
                    StatusCode = ""
            End Select

            Return StatusCode
        End Function

    End Class
End Namespace