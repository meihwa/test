﻿Public Interface IEmployeeInfo

    Property NoDataEmployee() As Int32
    Property NIK() As String
    Property Name() As String

End Interface
