﻿Imports IMFI.Framework.Persistance.DomainObjects
Imports IMFI.Template.Common

Public Class Search
    Inherits System.Web.UI.UserControl
    Private Const CURRENT_PAGING_PAGE As String = "CurrentPagingPage"
    Private Const CURRENT_PAGE_SEARCH As String = "CurrentPageSearch"
    Private Const CURRENT_SEARCH_CRITERIA_KATEGORY As String = "CurrentSearchCriteriaKategory"
    Private Const CURRENT_SEARCH_CRITERIA_KEY As String = "CurrentSearchCriteriaKey"
    Private Const CURRENT_SEARCH_CRITERIA As String = "CurrentSearchCriteria"

#Region "Event Handler"

    Public Event SearchData As EventHandler

#End Region

    'Public Event BuildCustomSearchCriteria As EventHandler

#Region "Page Handler"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not IsPostBack Then
            lsKeyKategori.DataSource = _SearchCriteria
            lsKeyKategori.DataTextField = "PairName"
            lsKeyKategori.DataValueField = "PairID"
            lsKeyKategori.DataBind()

            If Not Session(GetCurrentPageSearch) = PageURL.GetPageName() Then
                Session(GetCurrentPageSearch) = PageURL.GetPageName()
                SessionClear()
            Else
                If Session(GetCurrentSearchCriteriaKategory) <> "" Then
                    lsKeyKategori.SelectedValue = Session(GetCurrentSearchCriteriaKategory)
                    txtKey.Text = Session(GetCurrentSearchCriteriaKey)
                End If
            End If
        End If
    End Sub

#End Region

    'Public Event BindData As EventHandler
    Private Shared _SearchCriteria As ArrayList
    Private Shared _ReferenceKey As Hashtable
    Private Shared _CustomSearch As Hashtable

#Region "Private Variable"

    Private _FilterByBranch As Boolean

#End Region

#Region "Public Method"

    Public Sub Add(ByVal Key As String, ByVal Display As String)
        If (IsNothing(_SearchCriteria)) Then
            _SearchCriteria = New ArrayList
        End If
        _SearchCriteria.Add(New Pair(Key, Display))
    End Sub

    Public Sub AddReferenceKey(ByVal Key As String, ByVal ReferenceCodeDesc As String)
        If (IsNothing(_ReferenceKey)) Then
            _ReferenceKey = New Hashtable
        End If
        _ReferenceKey.Add(Key, ReferenceCodeDesc)
    End Sub

    Public Sub AddCustomSearch(ByVal Key As String, ByVal CustomSearch As String)
        If (IsNothing(_CustomSearch)) Then
            _CustomSearch = New Hashtable
        End If
        _CustomSearch.Add(Key, CustomSearch)
    End Sub

    Public Sub Clear()
        If (Not IsNothing(_SearchCriteria)) Then
            _SearchCriteria.Clear()
        End If
        If (Not IsNothing(_ReferenceKey)) Then
            _ReferenceKey.Clear()
        End If
    End Sub

    Public Sub ClearSearchCriteriaSession()
        SessionClear()
    End Sub

#End Region

#Region "Public Property"

    Public Property FilterByBranch() As Boolean
        Get
            Return _FilterByBranch
        End Get
        Set(ByVal Value As Boolean)
            _FilterByBranch = Value
        End Set
    End Property

    Public ReadOnly Property SearchCondition() As String
        Get
            Dim CurrentSearch As String = ""

            If Session(GetCurrentPageSearch) = PageURL.GetPageName() And Session(GetCurrentSearchCriteria) <> "" Then
                Return Session(GetCurrentSearchCriteria)
            End If

            Session(GetCurrentSearchCriteriaKategory) = lsKeyKategori.SelectedValue
            Session(GetCurrentSearchCriteriaKey) = txtKey.Text

            If Trim(txtKey.Text) = "" Or lsKeyKategori.SelectedValue.ToUpper = "SEMUA" Or lsKeyKategori.SelectedValue.ToUpper = "ALL" Then
                CurrentSearch = ""
            Else
                'RaiseEvent SearchData(lsKeyKategori, w)

                Dim oReferenceCode As String = ""
                If (Not IsNothing(_ReferenceKey)) Then
                    If _ReferenceKey.ContainsKey(lsKeyKategori.SelectedValue) Then
                        Dim ReferenceDelimiter As String

                        ReferenceDelimiter = _ReferenceKey(lsKeyKategori.SelectedValue)

                        Dim ReferenceCodeArray(ReferenceDelimiter.Split(";").Length) As String
                        ReferenceCodeArray = ReferenceDelimiter.Split(";")

                        For i As Int16 = 0 To ReferenceCodeArray.Length - 1
                            'If ReferenceCodeArray(i).ToString().ToUpper.Trim().IndexOf(Trim(txtKey.Text).ToUpper.Trim() + "=") > -1 Then
                            If ReferenceCodeArray(i).ToString().ToUpper.Trim().IndexOf(Trim(txtKey.Text).ToUpper.Trim()) > -1 Then
                                oReferenceCode = ReferenceCodeArray(i).Split("=")(1)
                                Exit For
                            End If
                        Next
                    End If
                End If

                'Cek For Custom Search
                If (Not IsNothing(_CustomSearch)) Then
                    If _CustomSearch.ContainsKey(lsKeyKategori.SelectedValue) Then
                        If oReferenceCode <> "" Then
                            CurrentSearch = CType(_CustomSearch(lsKeyKategori.SelectedValue), String).Replace("%%", "%" + oReferenceCode.Trim + "%")
                        Else
                            CurrentSearch = CType(_CustomSearch(lsKeyKategori.SelectedValue), String).Replace("%%", "%" + Trim(txtKey.Text) + "%")
                        End If
                    End If
                Else
                    If oReferenceCode <> "" Then
                        CurrentSearch = lsKeyKategori.SelectedValue.Trim + " like '%" + oReferenceCode.Trim + "%'"
                    Else
                        CurrentSearch = lsKeyKategori.SelectedValue.Trim + " like '%" + Trim(txtKey.Text.Replace("'", "''")) + "%'"
                    End If
                End If
            End If

            If FilterByBranch Then
                If CurrentSearch.Length = 0 Then
                    CurrentSearch = "BranchCode = '" + (New UserIdentification).GetUserCredential.BranchLoginInfo.BRANCH_CODE.ToString.Trim + "'"
                Else
                    CurrentSearch = CurrentSearch + " AND BranchCode = '" + (New UserIdentification).GetUserCredential.BranchLoginInfo.BRANCH_CODE.ToString.Trim + "'"
                End If
            End If

            If Not CurrentSearch.Length = 0 Then
                Session(GetCurrentSearchCriteria) = CurrentSearch
            End If

            Return CurrentSearch
        End Get
    End Property

    Public ReadOnly Property SearchCriteriaKey() As String
        Get
            If Session(GetCurrentPageSearch) = PageURL.GetPageName() And Session(GetCurrentSearchCriteriaKey) <> "" Then
                Return Session(GetCurrentSearchCriteriaKey)
            End If
            Return txtKey.Text
        End Get
    End Property

    Public ReadOnly Property SearchCriteriaKategory() As String
        Get
            If Session(GetCurrentPageSearch) = PageURL.GetPageName() And Session(GetCurrentSearchCriteriaKategory) <> "" Then
                Return Session(GetCurrentSearchCriteriaKategory)
            End If
            Return lsKeyKategori.SelectedValue
        End Get
    End Property

#End Region

#Region "Control Handler"

    Private Sub imgbtnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles imgbtnSearch.Click
        SessionClear()
        RaiseEvent SearchData(sender, e)
    End Sub

#End Region

#Region "Session"

    Private Function IsImplementFormBase() As Boolean
        Return Me.Parent.Page.GetType.BaseType.BaseType.Name.ToUpper = "FORMBASE"
    End Function

    Private Function GetCurrentPageSearch() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_PAGE_SEARCH + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_PAGE_SEARCH + PageURL.GetPageName()
        End If
    End Function

    Private Function GetCurrentSearchCriteriaKategory() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_SEARCH_CRITERIA_KATEGORY + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_SEARCH_CRITERIA_KATEGORY + PageURL.GetPageName()
        End If
    End Function

    Private Function GetCurrentSearchCriteriaKey() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_SEARCH_CRITERIA_KEY + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_SEARCH_CRITERIA_KEY + PageURL.GetPageName()
        End If
    End Function

    Private Function GetCurrentSearchCriteria() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_SEARCH_CRITERIA + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_SEARCH_CRITERIA + PageURL.GetPageName()
        End If
    End Function

    Private Function GetCurrentPagingPage() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_PAGING_PAGE + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_PAGING_PAGE + PageURL.GetPageName()
        End If
    End Function

    Private Sub SessionClear()
        Session(GetCurrentSearchCriteria) = ""
        Session(GetCurrentSearchCriteriaKategory) = ""
        Session(GetCurrentSearchCriteriaKey) = ""
        Session(GetCurrentPagingPage) = Nothing
    End Sub

#End Region

End Class