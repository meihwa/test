﻿Imports IMFI.Template.Common

Public Class Paging
    Inherits System.Web.UI.UserControl
    Private Const CURRENT_PAGING_PAGE As String = "CurrentPagingPage"
    Private Const CURRENT_PAGING As String = "CurrentPaging"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        If Not IsPostBack Then
            If Not Session(GetCurrentPaging) = PageURL.GetPageName() Then
                Session(GetCurrentPaging) = PageURL.GetPageName()
                SessionClear()
            End If
        End If

        If RowCount <= DefaultPagingSize Then
            Me.Visible = False
        End If
    End Sub

    Public Event BindData As EventHandler

#Region "Public Const"

    Public Const DefaultPagingSize As Int32 = 10

#End Region

#Region "Public Property"

    Public Property RowCount() As Int32
        Get
            If (IsNothing(ViewState("RowCount"))) Then
                ViewState("RowCount") = -1
            End If
            Return CType(ViewState("RowCount"), Int32)
        End Get
        Set(ByVal Value As Integer)
            ViewState("RowCount") = Value
            SetButton()
            Me.Visible = (Value > PageSize)
        End Set
    End Property

    Public Property PageSize() As Integer
        Get
            If (IsNothing(ViewState("PageSize"))) Then
                ViewState("PageSize") = DefaultPagingSize
            End If
            Return CType(ViewState("PageSize"), Int32)
        End Get
        Set(ByVal Value As Integer)
            ViewState("PageSize") = Value
        End Set
    End Property

    Public Property CurrentPage() As Integer
        Get
            Return ReturnCurrentPage()
        End Get
        Set(ByVal Value As Integer)
            Session(GetCurrentPagingPage) = Value
            ViewState("CurrentPage") = Value
        End Set
    End Property

    Public Property SearchCondition() As String
        Get
            If (IsNothing(ViewState("SearchCondition"))) Then
                ViewState("SearchCondition") = ""
            End If
            Return CType(ViewState("SearchCondition"), String)
        End Get
        Set(ByVal Value As String)
            ViewState("SearchCondition") = Value
        End Set
    End Property

    Private Shared _OrderBy As String

    Public Property OrderBy() As String
        Get
            If (IsNothing(ViewState("OrderBy"))) Then
                ViewState("OrderBy") = "WaktuDiubah ASC"
            End If
            Return CType(ViewState("OrderBy"), String)
        End Get
        Set(ByVal Value As String)
            ViewState("OrderBy") = Value
        End Set
    End Property

#End Region

#Region "Private Method"

    Private Function IsImplementFormBase() As Boolean
        Return Me.Parent.Page.GetType.BaseType.BaseType.Name.ToUpper = "FORMBASE"
    End Function

    Private Function GetCurrentPagingPage() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_PAGING_PAGE + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_PAGING_PAGE + PageURL.GetPageName()
        End If
    End Function

    Private Function GetCurrentPaging() As String
        If IsImplementFormBase() Then
            Return CType(Me.Parent.Page, FormBase).PageGroupId + CURRENT_PAGING + PageURL.GetPageName()
        Else
            Return "LOOKUP" + CURRENT_PAGING + PageURL.GetPageName()
        End If
    End Function

    Private Function NoOfPage() As Integer
        Dim iNoOfPage As Integer

        If PageSize > 0 Then
            iNoOfPage = RowCount \ PageSize

            If RowCount Mod PageSize Then
                iNoOfPage += 1
            End If
        Else
            iNoOfPage = 1
        End If

        Return iNoOfPage
    End Function

    Private Sub SetButton()
        imgBtnFirst.Enabled = (CurrentPage > 0)
        imgBtnPrevious.Enabled = (CurrentPage > 0)
        imgBtnLast.Enabled = (CurrentPage < NoOfPage() - 1)
        imgBtnNext.Enabled = (CurrentPage < NoOfPage() - 1)
        lblPage.InnerText = "Page " + (CurrentPage + 1).ToString + " of " + NoOfPage().ToString + " , Total " + RowCount.ToString() + " record(s)"

        If (PageSize = -1) Then
            imgBtnFirst.Enabled = False
            imgBtnPrevious.Enabled = False
            imgBtnLast.Enabled = False
            imgBtnNext.Enabled = False
            txtPage.Enabled = False
            imgBtnGo.Enabled = False
        End If
    End Sub

    Private Function ReturnCurrentPage() As Int32
        If IsNothing(Session(GetCurrentPagingPage)) Then
            Return 0
        Else
            Return CType(Session(GetCurrentPagingPage), Int32)
        End If
    End Function
#End Region

#Region "Control Handler"

    Private Sub imgbtnLast_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnLast.Click
        CurrentPage = NoOfPage() - 1
        SetButton()
        RaiseEvent BindData(sender, e)
    End Sub

    Private Sub imgbtnNext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnNext.Click
        CurrentPage += 1
        SetButton()
        RaiseEvent BindData(sender, e)
    End Sub

    Private Sub imgbtnPrev_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnPrevious.Click
        CurrentPage -= 1
        SetButton()
        RaiseEvent BindData(sender, e)
    End Sub

    Private Sub imgbtnFirst_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnFirst.Click
        CurrentPage = 0
        SetButton()
        RaiseEvent BindData(sender, e)
    End Sub

    Private Sub imgbtnGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnGo.Click
        If IsNumeric(txtPage.Text) Then
            If CType(txtPage.Text, Integer) <= NoOfPage() And CType(txtPage.Text, Integer) > 0 Then
                CurrentPage = CType(txtPage.Text, Integer) - 1
                SetButton()
                RaiseEvent BindData(sender, e)
            End If
        Else
            txtPage.Text = 1
        End If
    End Sub

#End Region

#Region "Session"

    Private Sub SessionClear()
        Session(GetCurrentPagingPage) = Nothing
    End Sub

#End Region

End Class