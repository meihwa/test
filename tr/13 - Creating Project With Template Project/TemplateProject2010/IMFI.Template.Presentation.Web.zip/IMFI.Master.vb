﻿Imports IMFI.Template.Common
Imports IMFI.Template.DomainObjects

Public Class IMFI
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim a As Literal

        a = Me.FindControl("lblUser")
        a.Text = (New UserIdentification).CurrentUserInfo.USER_ID
    End Sub

End Class