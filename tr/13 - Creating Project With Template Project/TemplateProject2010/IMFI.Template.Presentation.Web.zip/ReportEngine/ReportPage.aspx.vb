﻿Imports CrystalDecisions.CrystalReports.Engine
Imports IMFI.Template.ReportService
Imports IMFI.Template.Common

Public Class ReportPage
    Inherits System.Web.UI.Page

    Private repDoc As ReportDocument = Nothing

#Region "Form Handler"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim oService As New ReportingService
        Dim oReportParameterBuilder As New ReportParameterBuilder(Request.QueryString)
        Dim repDoc As New ReportDocument

        repDoc = oService.CreateReportDocument( _
            oReportParameterBuilder.ReportName, _
            oReportParameterBuilder.ParameterType, False, _
            oReportParameterBuilder.Parameter.ToArray())

        rvUserReport.ToolPanelView = CrystalDecisions.Web.ToolPanelViewType.None
        rvUserReport.ReportSource = repDoc

        If Not IsPostBack Then
            'txtfrom.Text = "0"
            'txtto.Text = "0"
            'cboprinterlist.DataSource = System.Drawing.Printing.PrinterSettings.InstalledPrinters
            'cboprinterlist.DataBind()
        End If
    End Sub

#End Region

    Private Sub ReportPage_Unload(sender As Object, e As System.EventArgs) Handles Me.Unload
        If Not IsNothing(repDoc) Then
            repDoc.Close()
            repDoc.Dispose()
        End If

        'rvUserReport.ReportSource = Nothing
        'rvUserReport.Dispose()
        'rvUserReport = Nothing

        'GC.WaitForPendingFinalizers()
        'GC.Collect()
    End Sub

End Class