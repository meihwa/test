﻿Imports IMFI.Framework.Persistance.DomainObjects.Core
Imports IMFI.Template.BusinessFacade
Imports IMFI.Template.DomainObjects
Imports IMFI.Template.Common
Imports IMFI.SC.DomainObjects

Public Class Login
    Inherits System.Web.UI.Page

#Region "Page Handler"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtPassword.Attributes.Add("Value", txtPassword.Text)
        SetFocus(txtUserName)
        errorboxcenter.Visible = False

        If Not IsPostBack Then
            FillBranch()
        End If

        '#If DEBUG Then
        '        Me.txtUserName.Text = "ADMINPC"
        '        Me.txtPassword.Text = "321"
        '        Me.ddlBranch.SelectedItem.Value = "101"
        '        btnLogin_Click(sender, Nothing)
        '#End If
    End Sub

#End Region

#Region "Control Handler"

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim oUserIdentification As UserIdentification = New UserIdentification
        Dim oIUserCredential As IUserCredential = CType((New SecurityWrapper).AuthenticateLogin(Me.txtUserName.Text, txtPassword.Text, ddlBranch.SelectedItem.Value, System.Configuration.ConfigurationManager.AppSettings("PREFIX_PROG_ID"), System.Configuration.ConfigurationManager.AppSettings("PREFIX_GROUP_ID")), IUserCredential)

        If Not oIUserCredential.IsLoginError AndAlso Trim(ddlBranch.SelectedItem.Value) <> "N/A" Then
            oUserIdentification.Register(oIUserCredential)
            DestroyPreviousPageGroupSession()

            If IsNothing(Session("BACKURL")) Then
                Response.Redirect("Dashboard.aspx")
            Else
                Response.Redirect(Session("BACKURL"))
            End If
        Else
            errorboxcenter.Visible = True
            lblLogin.Text = "Login Failed"
            lblMsg.Text = oIUserCredential.LoginMessage
        End If
    End Sub

    Private Overloads Sub SetFocus(ByVal ctrl As Control)
        Dim focusScript As String = "<script language='javascript'>" & "document.getElementById('" & ctrl.ClientID & "').focus();</script>"
        Page.ClientScript.RegisterStartupScript(ctrl.GetType, "FocusScript", focusScript)
    End Sub

#End Region

#Region "Private Constant"

    Private Const CURRENT_PAGE_GROUP_SESSION As String = "CURRENT_PAGE_GROUP_SESSION"
    Private Const PAGE_GROUP_SESSION As String = "PAGE_GROUP_SESSION"

#End Region

#Region "Private Property"

    Private Property CurrentPageGroupSession() As String
        Get
            If IsNothing(Session(CURRENT_PAGE_GROUP_SESSION)) Then
                Session(CURRENT_PAGE_GROUP_SESSION) = ""
            End If
            Return CType(Session(CURRENT_PAGE_GROUP_SESSION), String).Trim.ToUpper
        End Get
        Set(ByVal Value As String)
            Session(CURRENT_PAGE_GROUP_SESSION) = Value
        End Set
    End Property

#End Region

#Region "Private Method"

    Private Sub ClearSession(ByVal pageName As String)
        Dim oEnumerator As IEnumerator = Session.GetEnumerator()
        Dim oList As New ArrayList

        While oEnumerator.MoveNext
            Dim currentSession As String = CType(oEnumerator.Current(), String)
            If currentSession.IndexOf(pageName) > -1 Then
                oList.Add(currentSession)
            End If
        End While

        For index As Int16 = 0 To oList.Count - 1
            Session(oList(index)) = Nothing
            Session.Remove(oList(index))
        Next
    End Sub

    Private Sub ClearSessionByPageGroupID(ByVal pageGroupId As String)
        Dim oEnumerator As IEnumerator = Session.GetEnumerator()
        Dim oList As New ArrayList

        While oEnumerator.MoveNext
            Dim currentSession As String = CType(oEnumerator.Current(), String)
            If currentSession.IndexOf(pageGroupId) > -1 Then
                oList.Add(currentSession)
            End If
        End While

        For index As Int16 = 0 To oList.Count - 1
            Session(oList(index)) = Nothing
            Session.Remove(oList(index))
        Next
    End Sub

    Private Sub DestroyPreviousPageGroupSession()
        If CurrentPageGroupSession.Length > 0 Then
            Session(PAGE_GROUP_SESSION) = Nothing
            Session.Remove(PAGE_GROUP_SESSION)
            ClearSessionByPageGroupID(CurrentPageGroupSession)
            ClearSession("LOOKUP")
            ClearSession("CurrentFormMode")
        End If
    End Sub

    Private Sub PrepareUserIdentification(ByVal oIUserCredential As IUserCredential)
        Dim oUserIdentification As UserIdentification = New UserIdentification
        oUserIdentification.Register(oIUserCredential)
    End Sub

    Private Sub FillBranch()
        Dim oRowCount As Int16
        'Dim searchCondition As String

        Dim arAppType As ArrayList = (New BranchDataHelper).RetrievePagingList(-1, 0, "BRANCH_CODE_REP ASC", (New DomainObjects.ObjectTransporter(Nothing, Nothing)), Nothing, oRowCount)

        ddlBranch.Items.Clear()

        ddlBranch.Items.Add(New ListItem("Not Available", "N/A"))

        For i As Int16 = 0 To arAppType.Count - 1
            ddlBranch.Items.Add(New ListItem(CType(arAppType(i), DS_COMPANY_REP).BRANCH_CODE_REP.ToString & " - " & (New BranchFormat).BranchNameShort(CType(arAppType(i), DS_COMPANY_REP).BRANCH_NAME), CType(arAppType(i), DS_COMPANY_REP).BRANCH_CODE_REP.ToString))
        Next

        ddlBranch.SelectedValue = "N/A"
    End Sub

#End Region

End Class