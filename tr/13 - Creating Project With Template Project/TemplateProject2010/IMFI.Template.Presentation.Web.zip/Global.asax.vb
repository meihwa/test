﻿Imports System.Web.SessionState
Imports IMFI.Template.BusinessFacade
Imports IMFI.Template.Common

Public Class Global_asax
    Inherits System.Web.HttpApplication

    Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application is started
    End Sub

    Sub Session_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session is started
        FrameworkConfigurationWrapper.Configure()
    End Sub

    Sub Application_BeginRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires at the beginning of each request
    End Sub

    Sub Application_AuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires upon attempting to authenticate the use
        Dim lang As String = "id-ID"

        Try
            System.Threading.Thread.CurrentThread.CurrentCulture = _
                New System.Globalization.CultureInfo(lang)
        Catch
            ' NOOP
        End Try
    End Sub

    Sub Application_Error(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when an error occurs
        Dim ex As Exception = CType(Server.GetLastError(), Exception)
        Session("LAST_ERROR_URL") = HttpContext.Current.Request.Url.ToString()

        If Not IsNothing(ex) Then
            Session("ERROR") = Server.GetLastError()
        End If

        If IsNothing(Session(UserIdentification.USER_AUTORIZATION_SESSION_NAME)) Then
            Server.Transfer("~\Login.aspx")
        Else
            Server.Transfer("~\ErrorHandler\ErrorPage.aspx")
        End If
    End Sub

    Sub Session_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the session ends
    End Sub

    Sub Application_End(ByVal sender As Object, ByVal e As EventArgs)
        ' Fires when the application ends
    End Sub

End Class