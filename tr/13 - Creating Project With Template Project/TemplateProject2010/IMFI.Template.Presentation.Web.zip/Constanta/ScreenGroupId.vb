﻿Public Class ScreenGroupId

    Public Const MASTER_ACCOUNT_JOURNAL As String = "PCM0100"
    Public Const TRANSAKSI As String = "PCT0100"

End Class
