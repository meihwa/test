﻿Imports IMFI.SC.BusinessFacade
Imports IMFI.Framework.Persistance.DomainObjects.Core
Imports IMFI.Template.BusinessFacade
Imports IMFI.Template.DomainObjects
Imports IMFI.Template.Common

Public Class ChangePassword
    Inherits System.Web.UI.Page

#Region "Private Constant"

    Private Const CURRENT_PAGE_GROUP_SESSION As String = "CURRENT_PAGE_GROUP_SESSION"
    Private Const PAGE_GROUP_SESSION As String = "PAGE_GROUP_SESSION"

#End Region

#Region "Private Property"

    Private Property CurrentPageGroupSession() As String
        Get
            If IsNothing(Session(CURRENT_PAGE_GROUP_SESSION)) Then
                Session(CURRENT_PAGE_GROUP_SESSION) = ""
            End If
            Return CType(Session(CURRENT_PAGE_GROUP_SESSION), String).Trim.ToUpper
        End Get
        Set(ByVal Value As String)
            Session(CURRENT_PAGE_GROUP_SESSION) = Value
        End Set
    End Property

#End Region

#Region "Page Handler"

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'lblLogin.Visible = False
        Notif.Visible = False


        If Not IsPostBack Then
            Dim oUserIdentification As UserIdentification = New UserIdentification

            lblUserID.Text = oUserIdentification.CurrentEmployeeInfo.NIK.Trim + " - " + oUserIdentification.CurrentEmployeeInfo.Name
        End If
    End Sub

#End Region

#Region "Control Handler"

    Private Sub imgBtnChange_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles imgBtnChange.Click
        Dim isValid As Boolean = False
        Dim OldPass As String = (New SecurityWrapper).DecodePassword((New UserIdentification).CurrentUserInfo.USER_PASSWORD)

        If txtOldPassword.Text = OldPass Then
            If txtNewPassword.Text.Trim = txtRetypeNewPassword.Text Then
                isValid = True
            Else
                Notif.Visible = True
                lblError.Text = "Ulangi Password Baru Anda!"
                SetFocus(txtRetypeNewPassword)
            End If
        ElseIf txtOldPassword.Text.Trim.ToUpper = OldPass Then
            If txtNewPassword.Text.Trim = txtRetypeNewPassword.Text Then
                isValid = True
            Else
                Notif.Visible = True
                lblError.Text = "Ulangi Password Baru Anda!"
                SetFocus(txtRetypeNewPassword)
            End If
        Else
            Notif.Visible = True
            lblError.Text = "Password Lama Anda Salah!"
            SetFocus(txtOldPassword)
        End If

        If isValid Then
            Dim oSecurityWrapper As New SecurityWrapper
            Dim oChangePassword As IUserCredential = oSecurityWrapper.ChangePassword((New UserIdentification).GetUserCredential, txtNewPassword.Text)

            If Not oChangePassword.IsLoginError Then
                Notif.Visible = True
                lblError.Text = "Password Anda telah berhasil diubah"
                'RefreshUserCredential()
                Response.Redirect("Login.aspx")
            Else
                Notif.Visible = True
                lblError.Text = oChangePassword.LoginMessage
            End If
        End If
    End Sub

    Private Sub imgBtnCancel_Click(sender As Object, e As System.EventArgs) Handles imgBtnCancel.Click
        Response.Redirect("Login.aspx")
    End Sub

    'Private Sub RefreshUserCredential()
    '    Dim oUserIdentification As UserIdentification = New UserIdentification
    '    Dim oIUserCredential As IUserCredential = CType((New SecurityHelper).AuthenticateLogin(New UserIdentification().CurrentUserInfo.USER_ID, txtNewPassword.Text.Trim, New UserIdentification().CurrentBranchCode, System.Configuration.ConfigurationManager.AppSettings("PREFIX_PROG_ID"), System.Configuration.ConfigurationManager.AppSettings("PREFIX_GROUP_ID")), IUserCredential)

    '    If Not oIUserCredential.IsLoginError Then
    '        Dim Employee As New APS_Employee
    '        Employee.NIK = oIUserCredential.UserSysId
    '        Employee = New APS_EmployeeBusinessFacade().RetrieveByNIK(New ObjectTransporter(Employee, oIUserCredential))

    '        If Not IsNothing(Employee) Then
    '            oUserIdentification.Register(oIUserCredential, Employee)
    '            DestroyPreviousPageGroupSession()
    '        Else
    '            'TODO: Login Error
    '            Return
    '        End If
    '    End If
    'End Sub

#End Region

#Region "Private Methods"

    Private Sub ClearSession(ByVal pageName As String)
        Dim oEnumerator As IEnumerator = Session.GetEnumerator()
        Dim oList As New ArrayList

        While oEnumerator.MoveNext
            Dim currentSession As String = CType(oEnumerator.Current(), String)
            If currentSession.IndexOf(pageName) > -1 Then
                oList.Add(currentSession)
            End If
        End While

        For index As Int16 = 0 To oList.Count - 1
            Session(oList(index)) = Nothing
            Session.Remove(oList(index))
        Next
    End Sub

    Private Sub ClearSessionByPageGroupID(ByVal pageGroupId As String)
        Dim oEnumerator As IEnumerator = Session.GetEnumerator()
        Dim oList As New ArrayList

        While oEnumerator.MoveNext
            Dim currentSession As String = CType(oEnumerator.Current(), String)
            If currentSession.IndexOf(pageGroupId) > -1 Then
                oList.Add(currentSession)
            End If
        End While

        For index As Int16 = 0 To oList.Count - 1
            Session(oList(index)) = Nothing
            Session.Remove(oList(index))
        Next
    End Sub

    Private Sub DestroyPreviousPageGroupSession()
        If CurrentPageGroupSession.Length > 0 Then
            Session(PAGE_GROUP_SESSION) = Nothing
            Session.Remove(PAGE_GROUP_SESSION)
            ClearSessionByPageGroupID(CurrentPageGroupSession)
            ClearSession("LOOKUP")
            ClearSession("CurrentFormMode")
        End If
    End Sub

    Private Overloads Sub SetFocus(ByVal ctrl As Control)
        Dim focusScript As String = "<script language='javascript'>" & "document.getElementById('" & ctrl.ClientID & "').focus();</script>"
        Page.ClientScript.RegisterStartupScript(ctrl.GetType, "FocusScript", focusScript)
    End Sub

#End Region

End Class