﻿Public Enum ParameterType

    Index = 0
    Name = 1

End Enum
