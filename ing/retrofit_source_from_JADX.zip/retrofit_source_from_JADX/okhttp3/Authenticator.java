package okhttp3;

import java.io.IOException;

public interface Authenticator {
    public static final Authenticator NONE = new C03361();

    static class C03361 implements Authenticator {
        C03361() {
        }

        public Request authenticate(Route route, Response response) {
            return null;
        }
    }

    Request authenticate(Route route, Response response) throws IOException;
}
