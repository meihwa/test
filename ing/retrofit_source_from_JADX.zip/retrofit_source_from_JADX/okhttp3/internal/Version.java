package okhttp3.internal;

public final class Version {
    public static String userAgent() {
        return "okhttp/3.2.0";
    }

    private Version() {
    }
}
