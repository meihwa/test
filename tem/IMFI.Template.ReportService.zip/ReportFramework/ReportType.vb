﻿Public Enum ReportType

    PDF = 0
    Excel = 1

End Enum
