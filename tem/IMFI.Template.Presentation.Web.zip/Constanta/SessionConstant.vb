﻿Public Class SessionConstant

    Public Const NOT_AUTHORIZED As String = "NOT_AUTHORIZED"
    Public Const DEFAULT_DELETE_MESSAGE As String = "Data tidak dapat dihapus karena telah digunakan dalam transaksi."

End Class
