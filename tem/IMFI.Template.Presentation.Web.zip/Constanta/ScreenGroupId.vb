﻿Public Class ScreenGroupId

    'DASHBOARD
    Public Const DASHBOARD As String = "PPDD100"

End Class
