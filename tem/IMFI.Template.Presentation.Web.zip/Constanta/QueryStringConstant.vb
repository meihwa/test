﻿Public Class QueryStringConstant

    Public Const CLEAR_SESSION As String = "ClearSession"
    Public Const SAVE_MODE As String = "SaveMode"

End Class
